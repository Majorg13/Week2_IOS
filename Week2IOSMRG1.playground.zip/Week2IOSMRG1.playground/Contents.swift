import UIKit


var numeros = 1...100

for numeros in 1...100 {
    if numeros % 2 == 0 {
    print ( numeros , "#par" )
}
    if numeros % 2 == 1 {
    print ( numeros , "#impar" )
}
    if numeros % 5 == 0 {
    print ( numeros , "#Bingo!" )
    }
    if numeros > 29 && numeros < 41 {
        print ( numeros , "Viva Swift!!!" )
    }}


 
 /*

 var numeros = 1...100
 var reto = numeros


if reto { numeros; %2 == 0
    print ( numeros , "#par" )
}
    if numeros <% 2 == 1 {
    print ( numeros , "#impar" )
}
    if numeros <% 5 == 0 {
    print ( numeros , "#Bingo!" )
}
    for reto in numeros = 30...40 {
    print ( numeros , "Viva Swift!!!" )
}

/*
for reto in numeros { switch reto { case 1 : 5 ; 10 ; 15 ; 20 ; 25 ; 30 ; 35 ; 40 ; 45 ; 50 ; 55 ; 60 ; 65 ; 70 ; 75 ; 80 ; 85 ; 90 ; 95 ; 100
    print (numeros + "#Bingo!") } {
// sin multiplos de 5
case 2 : 2 ; 4 ; 6 ; 8 ; 10 ; 12 ; 14 ; 16 ; 18 ; 20 ; 22 ; 24 ; 26 ; 28 ; 32 ; 34 ; 36 ; 38 ; 42; 44 ; 46 ; 48 ; 52 ; 54 ; 56 ; 58 ; 62 ; 64 ; 66 ; 68 ; 72 ; 74 ; 76 ; 78 ; 82 ; 84 ; 86 ; 88 ; 92 ; 94 ; 96 ; 98
print (numeros + "#par") } {
case 3 : 1 ; 3 ; 5 ; 7 ; 9 ; 11 ; 13 ; 15 ; 17 ; 19 ; 21 ; 23 ; 25 ; 27 ; 29 ; 31 ; 33 ; 35 ; 37 ; 39 ; 41 ; 43 ; 45 ; 47 ; 49 ; 51 ; 53 ; 55 ; 57 ; 59 ; 61 ; 63 ; 65 ; 67 ; 69 ; 71 ; 73 ; 75 ; 77 ; 79 ; 81 ; 83 ; 85 ; 87 ; 89 ; 91 ; 93 ; 95 ; 97 ; 99
    print (numeros + "#inpar" ) } {
case 4 : 30...40
        print ( numeros + "Viva Swift!!!" )
    }
default: print ( "NA" )
}
*/
 */
